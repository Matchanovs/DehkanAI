// This file is intentionally left empty to disable and unregister any previous
// service worker, resolving potential loading issues with the application.
