
import { useState, useEffect } from 'react';

export interface UserProfile {
  name: string;
  location: string;
}

const STORAGE_KEY = 'dehqan-ai-profile';

export const useProfile = () => {
  const [profile, setProfile] = useState<UserProfile>({
    name: 'Dehqon',
    location: 'Toshkent'
  });

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setProfile(JSON.parse(stored));
      }
    } catch (e) {
      console.error("Failed to load profile", e);
    }
  }, []);

  const updateProfile = (newProfile: UserProfile) => {
    setProfile(newProfile);
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newProfile));
    } catch (e) {
        console.error("Failed to save profile", e);
    }
  };

  return { profile, updateProfile, setProfile };
};
