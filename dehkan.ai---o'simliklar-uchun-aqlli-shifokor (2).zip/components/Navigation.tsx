
import React from 'react';
import { HomeIcon } from './icons/HomeIcon';
import { HistoryIcon } from './icons/HistoryIcon';
import { HelpIcon } from './icons/HelpIcon';

export type NavPage = 'home' | 'history' | 'map' | 'help' | 'notifications' | 'profile';

interface NavigationProps {
  activePage: string;
  setPage: (page: NavPage) => void;
}

const NavItem: React.FC<{ label: string; icon: React.ReactNode; isActive: boolean; onClick: () => void }> = ({ label, icon, isActive, onClick }) => {
    const activeClass = isActive ? 'text-brand-green' : 'text-brand-gray';
    return (
        <button onClick={onClick} className={`flex flex-col items-center justify-center gap-1 w-full transition-colors ${activeClass} hover:text-brand-dark-green`}>
            {icon}
            <span className="text-xs font-medium">{label}</span>
        </button>
    );
}

export const Navigation: React.FC<NavigationProps> = ({ activePage, setPage }) => {
  return (
    <nav className="sticky bottom-0 w-full bg-white shadow-[0_-2px_5px_rgba(0,0,0,0.1)] z-10">
      <div className="container mx-auto flex items-center justify-around h-16">
        <NavItem 
            label="Bosh Sahifa" 
            icon={<HomeIcon className="w-6 h-6" />} 
            isActive={activePage === 'home'}
            onClick={() => setPage('home')} 
        />
        <NavItem 
            label="Tarix" 
            icon={<HistoryIcon className="w-6 h-6" />} 
            isActive={activePage === 'history'}
            onClick={() => setPage('history')} 
        />
        <NavItem 
            label="Yordam" 
            icon={<HelpIcon className="w-6 h-6" />} 
            isActive={activePage === 'help'}
            onClick={() => setPage('help')} 
        />
      </div>
    </nav>
  );
};
