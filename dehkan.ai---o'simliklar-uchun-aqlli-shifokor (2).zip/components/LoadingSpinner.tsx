
import React from 'react';

interface LoadingSpinnerProps {
    message?: string;
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ message = "Yuklanmoqda..." }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center p-8 space-y-4">
      <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-brand-green"></div>
      <p className="text-brand-dark-gray font-semibold text-lg">{message}</p>
    </div>
  );
};
