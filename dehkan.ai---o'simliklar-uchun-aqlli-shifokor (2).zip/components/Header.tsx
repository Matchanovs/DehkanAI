
import React from 'react';
import { LeafIcon } from './icons/LeafIcon';
import { NotificationIcon, UserIcon } from './icons/HomeIcons';
import { MapIcon } from './icons/MapIcon';

interface HeaderProps {
    onMapClick: () => void;
    onNotificationClick: () => void;
    onProfileClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onMapClick, onNotificationClick, onProfileClick }) => {
  return (
    <header className="bg-brand-light-gray w-full pt-4 px-4 pb-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <LeafIcon className="w-8 h-8 text-brand-green" />
          <h1 className="text-xl font-bold text-brand-dark-gray">
            Dehqan.AI
          </h1>
        </div>
        
        <div className="flex items-center gap-3">
             <button 
                onClick={onMapClick}
                className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-brand-dark-gray shadow-sm hover:bg-gray-50 active:scale-95 transition-all"
                aria-label="Xarita"
             >
                 <MapIcon className="w-5 h-5" />
             </button>
             <button 
                onClick={onNotificationClick}
                className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-brand-dark-gray shadow-sm hover:bg-gray-50 active:scale-95 transition-all relative"
                aria-label="Bildirishnomalar"
             >
                 <NotificationIcon className="w-5 h-5" />
                 <span className="absolute top-2 right-2.5 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
             </button>
             <button 
                onClick={onProfileClick}
                className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-brand-dark-gray shadow-sm hover:bg-gray-50 active:scale-95 transition-all"
                aria-label="Profil"
             >
                 <UserIcon className="w-5 h-5" />
             </button>
        </div>
      </div>
    </header>
  );
};
