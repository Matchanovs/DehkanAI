

import React from 'react';
import type { HistoryItem } from '../types';

interface DiagnosisResultProps {
  result: HistoryItem;
}

const ResultSection: React.FC<{ title: string; content: string; icon: React.ReactElement; }> = ({ title, content, icon }) => {
    const listItems = content.split('\n').map(item => item.trim().replace(/^- /, '')).filter(Boolean);

    return (
        <div className="bg-brand-light-gray p-4 rounded-lg">
            <h3 className="flex items-center text-lg font-semibold text-brand-dark-gray mb-2">
                {icon}
                <span className="ml-2">{title}</span>
            </h3>
            {listItems.length > 1 ? (
                 <ul className="list-disc list-inside text-brand-dark-gray space-y-1">
                    {listItems.map((item, index) => <li key={index}>{item}</li>)}
                </ul>
            ) : (
                <p className="text-brand-dark-gray">{content || "Ma'lumot mavjud emas."}</p>
            )}
        </div>
    );
};

const WeatherInfo: React.FC<{ weather: HistoryItem['weather'] }> = ({ weather }) => {
    if (!weather) return null;
    return (
      <div className="bg-blue-50 p-4 rounded-lg">
        <h3 className="flex items-center text-lg font-semibold text-blue-800 mb-2">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" /></svg>
          <span className="ml-2">Hozirgi Ob-havo</span>
        </h3>
        <p className="text-blue-700">Harorat: <strong>{weather.temp}°C</strong>, {weather.description}</p>
        <p className="text-blue-700">Namlik: <strong>{weather.humidity}%</strong> | Shamol: <strong>{weather.windSpeed} m/s</strong></p>
      </div>
    );
};


export const DiagnosisResult: React.FC<DiagnosisResultProps> = ({ result }) => {
  const { diagnosis, image, weather } = result;

  return (
    <div className="space-y-6">
      <h2 className="text-center text-2xl font-bold text-brand-dark-gray">Tashxis Natijasi</h2>
      <div className="flex justify-center">
          <img src={image} alt="Tashxis qilingan o'simlik" className="w-full max-h-72 object-contain rounded-xl shadow-md"/>
      </div>
      <div className="bg-green-100 border-l-4 border-brand-green text-brand-dark-green p-4 rounded-r-lg" role="alert">
        <p className="text-sm">Ekin Turi: {diagnosis.cropType}</p>
        <p className="font-bold text-xl">{diagnosis.name}</p>
      </div>

      <div className="space-y-4">
        <WeatherInfo weather={weather} />
        <ResultSection 
            title="Ob-havoga asoslangan tavsiyalar" 
            content={diagnosis.recommendations}
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.375 3.375 0 0014 18.442V19.5a3 3 0 01-6 0v-1.059a3.375 3.375 0 00-.74-2.006l-.548-.547z" /></svg>}
        />
        <ResultSection 
            title="Alomatlari" 
            content={diagnosis.symptoms} 
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>}
        />
        <ResultSection 
            title="Agrotexnik Usullar" 
            content={diagnosis.cultural}
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.121 15.879A6 6 0 0112.001 12m2.122-3.879A6 6 0 0012.001 6M12 21a9 9 0 100-18 9 9 0 000 18z" /></svg>}
        />
        <ResultSection 
            title="Kimyoviy Usullar" 
            content={diagnosis.chemical}
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547a2 2 0 00-.547 1.806l.477 2.387a6 6 0 00.517 3.86l.158.318a6 6 0 00.517 3.86l2.387.477a2 2 0 001.806-.547a2 2 0 00.547-1.806l-.477-2.387a6 6 0 00-.517-3.86l-.158-.318a6 6 0 01-.517-3.86l-2.387-.477a2 2 0 01-.547-1.806zM15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>}
        />
        <ResultSection 
            title="Xavfsizlik Choralari" 
            content={diagnosis.safety}
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
        />
      </div>
    </div>
  );
};