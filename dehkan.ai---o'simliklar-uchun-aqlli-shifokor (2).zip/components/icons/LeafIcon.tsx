
import React from 'react';

export const LeafIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    {...props}
  >
    <path
      d="M17.61,4.22A8.06,8.06,0,0,0,12,2a8,8,0,0,0-1,15.93,8.09,8.09,0,0,0,1-15.93V2a6,6,0,1,1,6,6H17.93A8.18,8.18,0,0,0,17.61,4.22Z"
    />
    <path
      d="M12,22A10,10,0,0,1,3.42,5.28,1,1,0,0,1,5.28,3.42,10,10,0,0,1,20.72,18.72,1,1,0,0,1,18.72,20.72,9.9,9.9,0,0,1,12,22Z"
    />
  </svg>
);
