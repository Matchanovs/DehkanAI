
import React, { useRef, useState } from 'react';
import { CameraIcon } from './icons/CameraIcon';
import { SparklesIcon } from './icons/SparklesIcon';
import { UploadIcon } from './icons/UploadIcon';

interface ImageUploaderProps {
  onImageUpload: (file: File) => void;
  onDiagnose: () => void;
  imagePreview: string | null;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, onDiagnose, imagePreview }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      onImageUpload(event.target.files[0]);
    }
     // Reset the input value to allow re-uploading the same file
    event.target.value = '';
  };

  return (
    <div className="text-center space-y-6">
      <h2 className="text-2xl font-bold text-brand-dark-gray">O'simlik kasalligini aniqlash</h2>
      <p className="text-brand-gray">Kasallangan o'simlikning (barg, poya, meva) aniq va yorug' rasmini yuklang.</p>
      
        <div className="relative">
            {imagePreview ? (
                <img src={imagePreview} alt="O'simlik prevyusi" className="w-full max-h-80 object-contain rounded-xl shadow-md" />
            ) : (
                <div className="w-full h-60 bg-gray-100 rounded-xl flex items-center justify-center">
                    <UploadIcon className="w-24 h-24 text-gray-300" />
                </div>
            )}
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
             <button
                onClick={() => cameraInputRef.current?.click()}
                className="w-full flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white border-2 border-brand-green text-brand-green font-bold rounded-xl hover:bg-green-50 transition-colors"
            >
                <CameraIcon className="w-6 h-6"/>
                Rasmga olish
            </button>
            <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white border-2 border-gray-300 text-brand-dark-gray font-bold rounded-xl hover:bg-gray-50 transition-colors"
            >
                <UploadIcon className="w-6 h-6"/>
                Fayl tanlash
            </button>
        </div>
        
        <input type="file" ref={cameraInputRef} onChange={handleFileChange} className="hidden" accept="image/*" capture="environment" />
        <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />


      {imagePreview && (
        <button
          onClick={onDiagnose}
          className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-brand-green text-white font-bold text-lg rounded-xl hover:bg-brand-dark-green focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-dark-green transition-transform transform hover:scale-105"
        >
          <SparklesIcon className="w-6 h-6"/>
          Tashxis qo'yish
        </button>
      )}
    </div>
  );
};
