
import type { Location } from '../types';

export const getCurrentLocation = (): Promise<Location> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      return reject(new Error('Geolokatsiya ushbu brauzerda mavjud emas.'));
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      },
      (error) => {
        // Default to Tashkent if permission denied or error (for demo purposes)
        console.warn("Location error:", error.message);
        resolve({ latitude: 41.3111, longitude: 69.2401 }); 
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  });
};

export const getLocationName = async (lat: number, lon: number): Promise<string> => {
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=10&accept-language=uz`);
        const data = await response.json();
        return data.address.city || data.address.town || data.address.county || data.address.state || "O'zbekiston";
    } catch (e) {
        console.error("Geocoding failed", e);
        return "Mening hududim";
    }
};
