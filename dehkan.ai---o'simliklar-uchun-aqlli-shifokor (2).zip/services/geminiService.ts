
import { GoogleGenAI, Type } from "@google/genai";
import type { Diagnosis, Weather } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const model = 'gemini-3-flash-preview';

const fileToGenerativePart = (base64Data: string, mimeType: string) => {
  return {
    inlineData: {
      data: base64Data,
      mimeType: mimeType,
    },
  };
};

const handleApiError = (error: any, context: string) => {
    console.error(`Gemini API error (${context}):`, error);
    const msg = error.toString().toLowerCase();
    if (msg.includes('429') || msg.includes('quota') || msg.includes('resource_exhausted')) {
        throw new Error("Server band (Limit tugadi). Iltimos, biroz kutib (30-60 soniya) qayta urining.");
    }
    throw new Error("Sun'iy intellekt bilan bog'lanishda xatolik yuz berdi. Internetni tekshiring.");
};

const diagnosisSchema = {
    type: Type.OBJECT,
    properties: {
        cropType: { type: Type.STRING, description: "O'simlikning turi, masalan Pomidor yoki Bodring" },
        name: { type: Type.STRING, description: "Kasallik yoki zararkunandaning nomi" },
        symptoms: { type: Type.STRING, description: "Kasallikning asosiy belgilari, alomatlari. Har bir alomat yangi qatordan boshlansin." },
        cultural: { type: Type.STRING, description: "Kimyoviy vositalarsiz, agrotexnik kurash usullari. Har bir usul yangi qatordan boshlansin." },
        chemical: { type: Type.STRING, description: "Kimyoviy kurash usullari, preparatlar nomi. Har bir usul yangi qatordan boshlansin." },
        safety: { type: Type.STRING, description: "Kimyoviy vositalar bilan ishlashdagi xavfsizlik choralari. Har bir chora yangi qatordan boshlansin." },
        recommendations: { type: Type.STRING, description: "Ob-havo va kasallik holatiga asoslangan 2-3 ta aniq amaliy tavsiyalar." },
        threatLevel: { 
            type: Type.STRING, 
            enum: ["low", "medium", "high"],
            description: "Xavf darajasi. 'low': yuqumli emas yoki sekin tarqaladi. 'medium': o'rta darajada tarqaladi. 'high': juda tez tarqaluvchi, qo'shni dalalarga xavf soluvchi epidemiya." 
        },
        threatDescription: { type: Type.STRING, description: "Nega bunday xavf darajasi qo'yilganligi haqida qisqa izoh (1 gap)." }
    },
    required: ["cropType", "name", "symptoms", "cultural", "chemical", "safety", "recommendations", "threatLevel", "threatDescription"]
};

const homeAdviceSchema = {
    type: Type.OBJECT,
    properties: {
        alert: {
            type: Type.OBJECT,
            properties: {
                hasAlert: { type: Type.BOOLEAN },
                title: { type: Type.STRING },
                message: { type: Type.STRING },
                severity: { type: Type.STRING, enum: ["low", "medium", "high"] }
            },
            required: ["hasAlert", "title", "message", "severity"]
        },
        dailyTip: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING },
                message: { type: Type.STRING }
            },
            required: ["title", "message"]
        },
        farmingCondition: {
            type: Type.STRING,
            description: "Qisqa fraza, masalan 'Purkash uchun qulay', 'Ekishga mos emas'"
        }
    },
    required: ["alert", "dailyTip", "farmingCondition"]
};

const detailedPlanSchema = {
    type: Type.OBJECT,
    properties: {
        reason: { type: Type.STRING, description: "Nega bu holat yuzaga keldi? Sababi." },
        actions: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "Dehqon bajarishi kerak bo'lgan aniq 3-4 ta harakatlar rejasi."
        },
        duration: { type: Type.STRING, description: "Bu holat qancha davom etishi kutilmoqda (prognoz)." }
    },
    required: ["reason", "actions", "duration"]
};


export const diagnosePlant = async (imageBase64: string, mimeType: string, weather: Weather | null): Promise<Diagnosis> => {
  const imagePart = fileToGenerativePart(imageBase64, mimeType);
  
  let weatherPrompt = "";
  if (weather) {
      weatherPrompt = `
      Ob-havo ma'lumotlari:
      - Harorat: ${weather.temp}°C
      - Namlik: ${weather.humidity}%
      - Holat: ${weather.description}
      
      Tavsiyalar (recommendations) berishda albatta shu ob-havo sharoitini hisobga ol! Masalan, yomg'irli havoda dori sepmaslik yoki issiqda ko'proq sug'orish kabi.
      `;
  }

  const prompt = `
    Sen O'zbekistondagi dehqonlarga yordam beruvchi "Dehqan.AI" nomli ekspert agronom-sun'iy intellektisan.
    Taqdim etilgan o'simlik rasmini tahlil qil va natijalarni JSON formatida taqdim et.
    
    ${weatherPrompt}

    Xavf darajasini (threatLevel) belgilashda juda ehtiyot bo'l:
    - Agar kasallik qo'shni dalalarga tez tarqalsa (masalan, Zang kasalligi, Un shudring, Ayrim zararkunandalar), 'high' deb belgilash SHART.
    - Agar kasallik faqat shu o'simlikka xos bo'lsa yoki sekin tarqalsa, 'low' yoki 'medium' belgilang.
    
    Javobing FAQAT O'ZBEK TILIDA bo'lsin.
  `;
  const textPart = { text: prompt };

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: [{ parts: [textPart, imagePart] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: diagnosisSchema,
      }
    });
    
    if (response && response.text) {
        return JSON.parse(response.text);
    } else {
        throw new Error('API dan bo\'sh javob qaytdi.');
    }
  } catch (error) {
    handleApiError(error, 'diagnosePlant');
    throw error; // unreachable due to handleApiError throwing, but for type safety
  }
};

export const getHomeAdvice = async (weather: Weather): Promise<any> => {
    const prompt = `
        Sen O'zbekistonlik dehqonlar uchun aqlli yordamchisan. 
        Quyidagi ob-havo ma'lumotlariga asoslanib, dehqon uchun muhim ogohlantirish (agar bo'lsa) va kunlik maslahat ber.
        
        Ob-havo:
        - Harorat: ${weather.temp}°C
        - Holat: ${weather.description}
        - Namlik: ${weather.humidity}%
        - Shamol: ${weather.windSpeed} km/s
        - Bugungi yomg'ir ehtimoli: ${weather.rainChance}%
        - Ertangi prognoz: ${weather.forecast[1].temp}°C, ${weather.forecast[1].rainChance}% yomg'ir.

        Javobni JSON formatida qaytar:
        1. "alert": Agar ob-havo keskin o'zgarsa yoki kasallik xavfi bo'lsa, ogohlantirish ber (hasAlert=true). 
        2. "dailyTip": Dehqonga bugungi ishlar bo'yicha qisqa maslahat.
        3. "farmingCondition": Masalan "Dori sepish uchun qulay" yoki "Sug'orishni to'xtating".
    `;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: [{ parts: [{ text: prompt }] }],
            config: {
                responseMimeType: "application/json",
                responseSchema: homeAdviceSchema,
            }
        });
        
        if (response && response.text) {
             return JSON.parse(response.text);
        }
        return null;
    } catch (e) {
        // Fallback is essential for home page stability
        return {
            alert: { hasAlert: false, title: "Xavfsiz ob-havo", message: "Hozircha hech qanday jiddiy xavf mavjud emas.", severity: "low" },
            dailyTip: { title: "Kun maslahati", message: "Ekinlaringizni muntazam tekshirib turing." },
            farmingCondition: "Dala ishlari uchun qulay"
        };
    }
};

export const getDetailedAlertPlan = async (weather: Weather, alertTitle: string, alertMessage: string): Promise<any> => {
    const prompt = `
        Dehqonga berilgan quyidagi ogohlantirish uchun batafsil harakatlar rejasini tuzib ber.
        
        Ogohlantirish: ${alertTitle} - ${alertMessage}
        Ob-havo: ${weather.description}, ${weather.temp}C, Namlik: ${weather.humidity}%

        Quyidagilarni JSON formatida qaytar:
        1. "reason": Nega bu holat yuzaga keldi? (Sababi)
        2. "actions": Dehqon hozir bajarishi shart bo'lgan 3-4 ta aniq qadam (Array).
        3. "duration": Bu holat qancha davom etishi mumkin va qachon ishga qaytish mumkin.
        
        Tili: O'zbek tili.
    `;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: [{ parts: [{ text: prompt }] }],
            config: {
                responseMimeType: "application/json",
                responseSchema: detailedPlanSchema,
            }
        });
        
        if (response && response.text) {
             return JSON.parse(response.text);
        }
        return null;
    } catch (e) {
        console.error("Failed to get detailed plan", e);
        // Do not throw here, return fallback to keep UI functional
        return {
            reason: "Ma'lumotni yuklashda xatolik.",
            actions: ["Xavfsizlik choralarini ko'ring.", "Mutaxassis bilan maslahatlashing."],
            duration: "Noma'lum."
        };
    }
};
