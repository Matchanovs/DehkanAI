
import type { UserProfile } from '../hooks/useProfile';

const USERS_STORAGE_KEY = 'dehqan-users-db';
const SESSION_KEY = 'dehqan-ai-profile'; // Matches the key used in useProfile

interface UserData extends UserProfile {
  phone: string;
  password: string;
}

export const authService = {
  // Register a new user
  register: async (name: string, phone: string, location: string, password: string): Promise<UserProfile> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));

    const usersStr = localStorage.getItem(USERS_STORAGE_KEY);
    const users: UserData[] = usersStr ? JSON.parse(usersStr) : [];

    // Check if phone already exists
    if (users.find(u => u.phone === phone)) {
      throw new Error('Bu telefon raqam allaqachon ro\'yxatdan o\'tgan.');
    }

    const newUser: UserData = { name, phone, location, password };
    users.push(newUser);
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));

    // Automatically log in
    const profile: UserProfile = { name, location };
    localStorage.setItem(SESSION_KEY, JSON.stringify(profile));
    
    return profile;
  },

  // Login existing user
  login: async (phone: string, password: string): Promise<UserProfile> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));

    const usersStr = localStorage.getItem(USERS_STORAGE_KEY);
    const users: UserData[] = usersStr ? JSON.parse(usersStr) : [];

    const user = users.find(u => u.phone === phone && u.password === password);

    if (!user) {
      throw new Error('Telefon raqam yoki parol noto\'g\'ri.');
    }

    const profile: UserProfile = { name: user.name, location: user.location };
    localStorage.setItem(SESSION_KEY, JSON.stringify(profile));

    return profile;
  },

  // Check if user is logged in
  getCurrentUser: (): UserProfile | null => {
    const session = localStorage.getItem(SESSION_KEY);
    return session ? JSON.parse(session) : null;
  },

  // Logout
  logout: () => {
    localStorage.removeItem(SESSION_KEY);
  }
};
