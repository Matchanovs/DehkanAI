
import type { Location, Weather } from '../types';

const getWeatherDescription = (code: number): string => {
  if (code === 0) return 'Ochiq havo';
  if (code === 1 || code === 2 || code === 3) return 'Bulutli';
  if (code >= 45 && code <= 48) return 'Tuman';
  if (code >= 51 && code <= 55) return 'Mayda yomg\'ir';
  if (code >= 61 && code <= 67) return 'Yomg\'ir';
  if (code >= 71 && code <= 77) return 'Qor';
  if (code >= 80 && code <= 82) return 'Jala';
  if (code >= 95 && code <= 99) return 'Momaqaldiroq';
  return 'O\'zgaruvchan';
};

export const getWeatherData = async (location: Location): Promise<Weather> => {
  try {
    const response = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}&longitude=${location.longitude}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,precipitation_probability_max&timezone=auto`
    );
    
    if (!response.ok) throw new Error("Weather API failed");
    
    const data = await response.json();
    const current = data.current;
    const daily = data.daily;

    const forecast = daily.time.slice(0, 3).map((time: string, index: number) => {
        const date = new Date(time);
        const isToday = index === 0;
        const isTomorrow = index === 1;
        
        let dayLabel = '';
        if (isToday) dayLabel = 'BUGUN';
        else if (isTomorrow) dayLabel = 'ERTAGA';
        else {
             const dayNames = ['YAK', 'DUSH', 'SESH', 'CHOR', 'PAY', 'JUMA', 'SHAN'];
             dayLabel = dayNames[date.getDay()];
        }

        return {
            day: dayLabel,
            temp: Math.round(daily.temperature_2m_max[index]),
            description: getWeatherDescription(daily.weather_code[index]),
            rainChance: daily.precipitation_probability_max[index] || 0
        };
    });

    return {
      temp: Math.round(current.temperature_2m),
      description: getWeatherDescription(current.weather_code),
      humidity: current.relative_humidity_2m,
      windSpeed: Math.round(current.wind_speed_10m),
      rainChance: daily.precipitation_probability_max[0] || 0,
      forecast: forecast
    };
  } catch (error) {
    console.error("Error fetching weather:", error);
    // Fallback data if API fails
    return {
        temp: 25,
        description: "Ochiq havo",
        humidity: 40,
        windSpeed: 5,
        rainChance: 0,
        forecast: [
            { day: "BUGUN", temp: 25, description: "Ochiq", rainChance: 0 },
            { day: "ERTAGA", temp: 24, description: "Bulutli", rainChance: 10 },
            { day: "YAK", temp: 26, description: "Ochiq", rainChance: 0 }
        ]
    };
  }
};
