
import React, { useState } from 'react';
import { LeafIcon } from '../components/icons/LeafIcon';
import { authService } from '../services/authService';
import type { UserProfile } from '../hooks/useProfile';

interface AuthPageProps {
  onLoginSuccess: (user: UserProfile) => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onLoginSuccess }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    location: '',
    password: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError(null); // Clear error on type
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      if (isRegister) {
        if (!formData.name || !formData.phone || !formData.password || !formData.location) {
          throw new Error("Iltimos, barcha maydonlarni to'ldiring.");
        }
        const user = await authService.register(formData.name, formData.phone, formData.location, formData.password);
        onLoginSuccess(user);
      } else {
        if (!formData.phone || !formData.password) {
          throw new Error("Telefon raqam va parolni kiriting.");
        }
        const user = await authService.login(formData.phone, formData.password);
        onLoginSuccess(user);
      }
    } catch (err: any) {
      setError(err.message || "Xatolik yuz berdi. Qaytadan urinib ko'ring.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-brand-light-gray flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Decorations */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-green-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
      <div className="absolute top-0 right-0 w-64 h-64 bg-teal-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
      <div className="absolute -bottom-32 left-20 w-64 h-64 bg-pink-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000"></div>

      <div className="w-full max-w-md bg-white rounded-3xl shadow-xl p-8 relative z-10">
        <div className="flex flex-col items-center mb-8">
          <div className="bg-green-50 p-4 rounded-full mb-4">
            <LeafIcon className="w-12 h-12 text-brand-green" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Dehqan.AI</h1>
          <p className="text-gray-500 text-sm mt-1 text-center">
            {isRegister 
              ? "Yangi hisob yaratish va ekinlaringizni himoya qilishni boshlang." 
              : "Xush kelibsiz! Davom ettirish uchun kiring."}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="bg-red-50 text-red-600 text-sm p-3 rounded-xl border border-red-100 text-center">
              {error}
            </div>
          )}

          {isRegister && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1 ml-1">Ismingiz</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:bg-white focus:ring-2 focus:ring-brand-green focus:border-transparent outline-none transition-all"
                  placeholder="Ism Familiya"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1 ml-1">Hududingiz</label>
                <input
                  type="text"
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:bg-white focus:ring-2 focus:ring-brand-green focus:border-transparent outline-none transition-all"
                  placeholder="Masalan: Toshkent"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1 ml-1">Telefon raqam</label>
            <input
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:bg-white focus:ring-2 focus:ring-brand-green focus:border-transparent outline-none transition-all"
              placeholder="+998 90 123 45 67"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1 ml-1">Parol</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:bg-white focus:ring-2 focus:ring-brand-green focus:border-transparent outline-none transition-all"
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-brand-green text-white font-bold py-4 rounded-xl shadow-lg shadow-green-200 hover:bg-brand-dark-green active:scale-95 transition-all mt-6 disabled:opacity-70 flex justify-center"
          >
            {isLoading ? (
              <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : (
              isRegister ? "Ro'yxatdan o'tish" : "Kirish"
            )}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-gray-500 text-sm">
            {isRegister ? "Hisobingiz bormi?" : "Hali hisobingiz yo'qmi?"}
            <button
              onClick={() => {
                setIsRegister(!isRegister);
                setError(null);
                setFormData({name: '', phone: '', location: '', password: ''});
              }}
              className="text-brand-green font-bold ml-1 hover:underline focus:outline-none"
            >
              {isRegister ? "Kirish" : "Ro'yxatdan o'tish"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};
