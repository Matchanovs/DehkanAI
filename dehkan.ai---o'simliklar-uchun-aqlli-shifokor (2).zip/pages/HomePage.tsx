
import React, { useEffect, useState } from 'react';
import type { HistoryItem, Weather } from '../types';
import type { UserProfile } from '../hooks/useProfile';
import { CameraIcon } from '../components/icons/CameraIcon';
import { 
    LocationIcon, WindIcon, DropIcon, SunIcon, CloudIcon, 
    ChevronRightIcon, CheckCircleIcon, ClockIcon 
} from '../components/icons/HomeIcons';
import { getWeatherData } from '../services/weatherService';
import { getCurrentLocation, getLocationName } from '../services/locationService';
import { getHomeAdvice } from '../services/geminiService';

interface HomePageProps {
  history: HistoryItem[];
  onDiagnoseClick: () => void;
  onSelectItem: (item: HistoryItem) => void;
  onAdviceClick: (advice: any, weather: any) => void;
  userProfile: UserProfile;
}

export const HomePage: React.FC<HomePageProps> = ({ history, onDiagnoseClick, onSelectItem, onAdviceClick, userProfile }) => {
  const [weather, setWeather] = useState<Weather | null>(null);
  const [advice, setAdvice] = useState<any>(null);
  const [locationName, setLocationName] = useState<string>("Joylashuv aniqlanmoqda...");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initData = async () => {
        try {
            let loc;
            try {
                loc = await getCurrentLocation();
                const detectedName = await getLocationName(loc.latitude, loc.longitude);
                setLocationName(userProfile.location !== 'Toshkent' ? userProfile.location : detectedName);
            } catch (e) {
                loc = { latitude: 41.3111, longitude: 69.2401 };
                setLocationName(userProfile.location);
            }

            const weatherData = await getWeatherData(loc);
            setWeather(weatherData);

            const adviceData = await getHomeAdvice(weatherData);
            setAdvice(adviceData);

        } catch (e) {
            console.error("Initialization failed", e);
        } finally {
            setLoading(false);
        }
    };
    initData();
  }, [userProfile.location]);

  const recentHistory = history.slice(0, 5);

  return (
    <div className="space-y-6 pb-20">
      
      {/* Greeting Section */}
      <div className="mt-2">
        <p className="text-gray-500 text-lg">Xayrli kun,</p>
        <h1 className="text-3xl font-extrabold text-gray-900">{userProfile.name}</h1>
        <div className="flex items-center text-gray-500 mt-2 bg-white w-fit px-3 py-1.5 rounded-full shadow-sm text-sm">
          <LocationIcon className="w-4 h-4 text-brand-green mr-1.5" />
          <span>{locationName}</span>
        </div>
      </div>

      {/* Weather Card */}
      <div className="bg-white rounded-3xl p-5 shadow-sm relative overflow-hidden">
         <div className="flex justify-between items-start mb-4">
            <h2 className="font-bold text-lg text-gray-900">Ob-havo</h2>
            <span className="bg-gray-100 text-gray-500 px-3 py-1 rounded-full text-xs font-medium uppercase">{weather?.description || "..."}</span>
         </div>
         
         {weather && advice ? (
             <>
                <div className={`rounded-2xl p-4 mb-5 border ${advice.farmingCondition.toLowerCase().includes('qulay') ? 'bg-green-50 border-green-100' : 'bg-orange-50 border-orange-100'}`}>
                    <div className={`flex items-center gap-2 font-bold mb-3 ${advice.farmingCondition.toLowerCase().includes('qulay') ? 'text-green-700' : 'text-orange-700'}`}>
                        <span className={`w-2.5 h-2.5 rounded-full animate-pulse ${advice.farmingCondition.toLowerCase().includes('qulay') ? 'bg-green-500' : 'bg-orange-500'}`}></span>
                        {advice.farmingCondition}
                    </div>
                    <div className="flex gap-6 text-gray-600 text-sm font-medium">
                        <div className="flex items-center gap-1.5">
                            <WindIcon className="w-5 h-5 text-blue-400" />
                            {weather.windSpeed} km/s
                        </div>
                        <div className="flex items-center gap-1.5">
                            <DropIcon className="w-5 h-5 text-blue-400" />
                            {weather.rainChance}% yomg'ir
                        </div>
                    </div>
                </div>

                <h3 className="text-xs font-bold text-gray-400 uppercase mb-3 tracking-wider">3 kunlik prognoz</h3>
                <div className="grid grid-cols-3 gap-2">
                    {weather.forecast.map((day, idx) => (
                        <div key={idx} className="bg-brand-light-gray/50 rounded-2xl p-3 flex flex-col items-center text-center">
                            <span className="text-xs text-gray-500 font-semibold mb-2">{day.day}</span>
                            {day.rainChance > 40 ? <DropIcon className="w-8 h-8 text-blue-500 mb-1"/> : 
                             day.rainChance > 10 ? <CloudIcon className="w-8 h-8 text-gray-400 mb-1"/> : 
                             <SunIcon className="w-8 h-8 text-orange-400 mb-1"/>}
                            <span className="text-lg font-bold text-gray-800">{day.temp}°</span>
                            <span className="text-[10px] text-blue-500 font-medium">{day.rainChance > 0 ? `${day.rainChance}%` : "Yog'in yo'q"}</span>
                        </div>
                    ))}
                </div>
             </>
         ) : (
             <div className="animate-pulse space-y-4">
                 <div className="h-20 bg-gray-100 rounded-xl"></div>
                 <div className="h-24 bg-gray-100 rounded-xl"></div>
             </div>
         )}
      </div>
      
      {/* Scan Button (Floating/Prominent) */}
      <div className="flex justify-center -my-2">
           <button 
                onClick={onDiagnoseClick}
                className="w-24 h-24 rounded-full bg-gradient-to-tr from-brand-green to-teal-400 shadow-lg shadow-green-200 border-4 border-white flex flex-col items-center justify-center text-white transform transition active:scale-95 group z-10"
           >
                <CameraIcon className="w-8 h-8 mb-1 group-hover:scale-110 transition-transform"/>
                <span className="text-[10px] font-bold">Skanerlash</span>
           </button>
      </div>

      {/* Recent Diagnoses Carousel */}
      <div>
          <div className="flex justify-between items-center mb-3">
            <h2 className="font-bold text-lg text-gray-900">So'nggi tashxislar</h2>
            <button className="text-brand-green text-sm font-bold flex items-center">
                Barchasi <ChevronRightIcon className="w-4 h-4" />
            </button>
          </div>
          
          <div className="flex gap-4 overflow-x-auto pb-4 -mx-4 px-4 scrollbar-hide snap-x">
             {recentHistory.length > 0 ? recentHistory.map((item) => (
                 <div key={item.id} onClick={() => onSelectItem(item)} className="min-w-[160px] bg-white p-4 rounded-2xl shadow-sm border border-gray-100 snap-center cursor-pointer active:scale-95 transition-transform">
                     <div className="flex justify-between items-start mb-3">
                         <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center overflow-hidden">
                             <img src={item.image} className="w-full h-full object-cover" alt="crop"/>
                         </div>
                         {item.diagnosis.name !== 'Sog\'lom' ? (
                             <ClockIcon className="w-5 h-5 text-orange-400" />
                         ) : (
                             <CheckCircleIcon className="w-5 h-5 text-green-500" />
                         )}
                     </div>
                     <span className="text-xs text-gray-400 block mb-1">{new Date(item.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                     <h3 className="font-bold text-gray-900 text-lg leading-tight mb-1">{item.diagnosis.cropType}</h3>
                     <p className="text-sm text-gray-500 truncate mb-3">{item.diagnosis.name}</p>
                     <div className={`text-xs font-bold px-3 py-1.5 rounded-lg text-center ${
                         item.diagnosis.name !== 'Sog\'lom' ? 'bg-orange-50 text-orange-500' : 'bg-green-50 text-green-600'
                     }`}>
                         {item.diagnosis.name !== 'Sog\'lom' ? 'Davolash kerak' : 'Davolangan'}
                     </div>
                 </div>
             )) : (
                 // Empty State
                 <div className="w-full text-center py-4 bg-white rounded-2xl border border-dashed border-gray-300">
                     <p className="text-gray-400 text-sm">Hozircha tashxislar yo'q</p>
                 </div>
             )}
          </div>
      </div>

      {/* AI Advice Card - Redesigned (Blue Card) */}
      {advice && advice.alert.hasAlert && (
         <div className="bg-blue-600 rounded-3xl p-6 text-white relative overflow-hidden shadow-lg shadow-blue-200">
            {/* Background Decorations */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full blur-xl -ml-10 -mb-10"></div>
            
            <div className="relative z-10">
                <div className="flex justify-between items-start mb-4">
                    <h2 className="font-bold text-xl w-3/4 leading-tight">{advice.alert.title}</h2>
                    <span className="bg-white/20 backdrop-blur-md px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wide">AI Tavsiyasi</span>
                </div>
                
                <p className="text-blue-50 text-sm mb-6 leading-relaxed opacity-90">
                    {advice.alert.message}
                </p>

                <button 
                    onClick={() => onAdviceClick(advice, weather)}
                    className="w-full bg-white text-blue-600 font-bold py-3.5 rounded-xl hover:bg-blue-50 transition-colors shadow-sm active:scale-95 transform"
                >
                    Batafsil o'qish
                </button>
            </div>
         </div>
      )}
      
      {/* Fallback for non-alert advice (Daily Tip) */}
      {advice && !advice.alert.hasAlert && (
          <div className="bg-green-600 rounded-3xl p-6 text-white relative overflow-hidden shadow-lg shadow-green-200">
             <div className="relative z-10">
                <div className="flex justify-between items-start mb-3">
                    <h2 className="font-bold text-xl">{advice.dailyTip.title}</h2>
                    <span className="bg-white/20 backdrop-blur-md px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase">AI Maslahat</span>
                </div>
                <p className="text-green-50 text-sm mb-5 leading-relaxed">
                    {advice.dailyTip.message}
                </p>
                <button 
                    onClick={() => onAdviceClick(advice, weather)}
                    className="w-full bg-white text-green-600 font-bold py-3 rounded-xl hover:bg-green-50 transition-colors"
                >
                    Batafsil o'qish
                </button>
             </div>
          </div>
      )}

    </div>
  );
};
