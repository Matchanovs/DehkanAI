
import React from 'react';
import type { HistoryItem } from '../types';

interface HistoryPageProps {
  history: HistoryItem[];
  onSelect: (item: HistoryItem) => void;
}

export const HistoryPage: React.FC<HistoryPageProps> = ({ history, onSelect }) => {
  if (history.length === 0) {
    return (
      <div className="text-center p-8 text-brand-gray">
        <h3 className="font-bold text-lg">Tashxislar tarixi yo'q</h3>
        <p>Sizning saqlangan tashxislaringiz shu yerda paydo bo'ladi.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-center text-2xl font-bold text-brand-dark-gray">Tashxislar Tarixi</h2>
      {history.sort((a, b) => b.timestamp - a.timestamp).map(item => (
        <div key={item.id} onClick={() => onSelect(item)} className="flex items-center gap-4 bg-white p-3 rounded-lg shadow-sm cursor-pointer hover:shadow-md transition-shadow">
          <img src={item.image} alt={item.diagnosis.name} className="w-20 h-20 object-cover rounded-md" />
          <div className="flex-grow">
            <p className="font-bold text-brand-dark-gray">{item.diagnosis.name}</p>
            <p className="text-sm text-brand-gray">{new Date(item.timestamp).toLocaleString()}</p>
          </div>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
          </svg>
        </div>
      ))}
    </div>
  );
};