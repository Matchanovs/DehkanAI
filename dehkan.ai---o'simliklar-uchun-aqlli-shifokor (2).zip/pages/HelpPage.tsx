import React from 'react';
import { DiagnoseIcon } from '../components/icons/DiagnoseIcon';
import { HistoryIcon } from '../components/icons/HistoryIcon';
import { MapIcon } from '../components/icons/MapIcon';

const Accordion: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode }> = ({ title, icon, children }) => {
    return (
        <details className="group border border-gray-200 rounded-lg overflow-hidden">
            <summary className="flex items-center gap-3 p-4 cursor-pointer hover:bg-gray-50 list-none">
                <div className="text-brand-green">{icon}</div>
                <h3 className="font-semibold text-brand-dark-gray">{title}</h3>
                <div className="ml-auto transition-transform duration-300 group-open:rotate-180">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                </div>
            </summary>
            <div className="p-4 border-t border-gray-200 bg-brand-light-gray/50 text-brand-gray">
                {children}
            </div>
        </details>
    )
}

export const HelpPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-center text-2xl font-bold text-brand-dark-gray">Yordam va Qo'llanmalar</h2>
      
      <Accordion title="Qanday qilib to'g'ri tashxis qo'yish kerak?" icon={<DiagnoseIcon className="w-6 h-6"/>}>
          <ul className="list-disc list-inside space-y-2">
              <li><strong>Aniq rasmga oling:</strong> O'simlikning kasallangan qismini (barg, poya, meva) aniq fokusda va yaxshi yoritilgan joyda rasmga oling.</li>
              <li><strong>Yaqindan oling:</strong> Kasallik belgilari aniq ko'rinishi uchun rasmni iloji boricha yaqinroqdan oling.</li>
              <li><strong>Bitta kasallik, bitta rasm:</strong> Har bir rasmda faqat bitta kasallik belgilari bo'lganiga e'tibor bering.</li>
              <li><strong>Fonni hisobga oling:</strong> Orqa fon sodda bo'lsin, bu sun'iy intellektga kasallikni aniqlashda yordam beradi.</li>
          </ul>
      </Accordion>

      <Accordion title="Tashxislar tarixini ko'rish" icon={<HistoryIcon className="w-6 h-6"/>}>
          <p>
              "Tarix" bo'limiga o'tib, avvalgi barcha tashxislaringiz ro'yxatini ko'rishingiz mumkin. Har bir yozuvni bosish orqali uning to'liq tafsilotlarini, jumladan, rasm, tashxis natijasi va berilgan tavsiyalarni qayta ko'rib chiqishingiz mumkin.
          </p>
      </Accordion>

      <Accordion title="Xaritadan foydalanish" icon={<MapIcon className="w-6 h-6"/>}>
          <p>
              "Xarita" bo'limi sizning tashxislaringiz qayerda amalga oshirilganini ko'rsatadi. Bu ma'lum bir hududda qaysi kasalliklar tarqalganini kuzatish uchun foydalidir. Xaritadagi har bir belgi bitta tashxisni anglatadi va uni bosish orqali qisqacha ma'lumot olishingiz mumkin.
          </p>
      </Accordion>

    </div>
  );
};