
import React from 'react';
import { WarningIcon, CheckCircleIcon, ClockIcon } from '../components/icons/HomeIcons';

export const NotificationsPage: React.FC = () => {
    const notifications = [
        { id: 1, type: 'warning', title: 'Ob-havo ogohlantirishi', message: 'Ertaga kuchli shamol (15 m/s) kutilmoqda. Ekinlarni himoyalash choralarini ko\'ring.', time: '1 soat oldin' },
        { id: 2, type: 'success', title: 'Tashxis saqlandi', message: 'Pomidor o\'simligi bo\'yicha tashxis muvaffaqiyatli saqlandi.', time: 'Bugun, 09:30' },
        { id: 3, type: 'info', title: 'Yangi maslahat', message: 'Kuzgi bug\'doy ekish mavsumi yaqinlashmoqda. Tuproqni tayyorlashni unutmang.', time: 'Kecha' },
        { id: 4, type: 'info', title: 'Ilova yangilandi', message: 'Yangi funksiyalar qo\'shildi: Ob-havo tahlili va Xarita.', time: '2 kun oldin' },
    ];

    return (
        <div className="space-y-4">
            <h2 className="text-2xl font-bold text-brand-dark-gray mb-4">Bildirishnomalar</h2>
            <div className="space-y-3">
                {notifications.map(notif => (
                    <div key={notif.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex gap-3 items-start">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 
                            ${notif.type === 'warning' ? 'bg-orange-100 text-orange-500' : 
                              notif.type === 'success' ? 'bg-green-100 text-green-500' : 'bg-blue-100 text-blue-500'}`}>
                            {notif.type === 'warning' ? <WarningIcon className="w-6 h-6"/> :
                             notif.type === 'success' ? <CheckCircleIcon className="w-6 h-6"/> :
                             <ClockIcon className="w-6 h-6"/>}
                        </div>
                        <div className="flex-1">
                            <div className="flex justify-between items-start">
                                <h3 className="font-bold text-gray-900 text-sm">{notif.title}</h3>
                                <span className="text-gray-400 text-[10px] whitespace-nowrap ml-2">{notif.time}</span>
                            </div>
                            <p className="text-gray-600 text-xs mt-1 leading-relaxed">{notif.message}</p>
                        </div>
                    </div>
                ))}
            </div>
            
            <div className="text-center pt-4">
                <button className="text-brand-gray text-sm hover:text-brand-green">Barcha o'qilgan deb belgilash</button>
            </div>
        </div>
    );
};
