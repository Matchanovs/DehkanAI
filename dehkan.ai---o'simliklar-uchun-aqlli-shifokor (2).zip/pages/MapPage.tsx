
import React, { useEffect, useState, useMemo } from 'react';
import L from 'leaflet';
import type { HistoryItem } from '../types';

interface MapPageProps {
  history: HistoryItem[];
  onBack: () => void;
}

const REGIONS: Record<string, { lat: number; lng: number; zoom: number }> = {
    'Toshkent': { lat: 41.2995, lng: 69.2401, zoom: 12 },
    'Samarqand': { lat: 39.6542, lng: 66.9597, zoom: 12 },
    'Farg\'ona': { lat: 40.3864, lng: 71.7864, zoom: 12 },
    'Navoiy': { lat: 40.1039, lng: 65.3688, zoom: 12 },
    'Qashqadaryo': { lat: 38.8986, lng: 65.7842, zoom: 12 },
};

export const MapPage: React.FC<MapPageProps> = ({ history, onBack }) => {
  const mapRef = React.useRef<L.Map | null>(null);
  const mapContainerRef = React.useRef<HTMLDivElement>(null);
  
  const [activeRegion, setActiveRegion] = useState('Barcha hududlar');
  const [selectedCrop, setSelectedCrop] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(false);

  // Extract unique crops for the filter
  const availableCrops = useMemo(() => {
      const crops = new Set<string>();
      history.forEach(item => crops.add(item.diagnosis.cropType));
      return Array.from(crops);
  }, [history]);

  // Filter history based on selected crop
  const filteredHistory = useMemo(() => {
      return history.filter(item => {
          if (selectedCrop !== 'all' && item.diagnosis.cropType !== selectedCrop) return false;
          return true;
      });
  }, [history, selectedCrop]);

  // Calculate Stats based on filtered view
  const stats = useMemo(() => {
    let high = 0;
    let medium = 0;
    let low = 0;

    filteredHistory.forEach(item => {
        const level = item.diagnosis.threatLevel || 'low';
        if (level === 'high') high++;
        else if (level === 'medium') medium++;
        else low++;
    });

    return { high, medium, low, total: filteredHistory.length };
  }, [filteredHistory]);

  const handleRegionChange = (region: string) => {
      setActiveRegion(region);
      if (!mapRef.current) return;

      if (region === 'Barcha hududlar') {
          // Fit bounds to all markers if there are any
          if (filteredHistory.length > 0 && filteredHistory[0].location) {
              const bounds = L.latLngBounds(filteredHistory.map(h => [h.location!.latitude, h.location!.longitude]));
              mapRef.current.fitBounds(bounds, { padding: [50, 50] });
          } else {
              mapRef.current.setView([41.3111, 69.2401], 6); // Default view of Uzbekistan
          }
      } else if (REGIONS[region]) {
          const { lat, lng, zoom } = REGIONS[region];
          mapRef.current.flyTo([lat, lng], zoom);
      }
  };

  // Initialize Map
  useEffect(() => {
    if (mapContainerRef.current && !mapRef.current) {
      // Default initial view
      const initialLat = 41.3111;
      const initialLon = 69.2401;

      mapRef.current = L.map(mapContainerRef.current, {
          zoomControl: false,
          attributionControl: false
      }).setView([initialLat, initialLon], 6);

      // Dark Mode Tiles
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        maxZoom: 20
      }).addTo(mapRef.current);
    }
  }, []);

  // Update Markers
  useEffect(() => {
    if (mapRef.current) {
        // Clear layers
        mapRef.current.eachLayer((layer) => {
            if (layer instanceof L.Marker) {
                mapRef.current?.removeLayer(layer);
            }
        });

        filteredHistory.forEach(item => {
            if (item.location) {
                const threatLevel = item.diagnosis.threatLevel || 'low';
                
                let color = '#22c55e'; // Green
                let ringColor = 'rgba(34, 197, 94, 0.3)';
                
                if (threatLevel === 'high') {
                    color = '#ef4444'; // Red
                    ringColor = 'rgba(239, 68, 68, 0.3)';
                } else if (threatLevel === 'medium') {
                    color = '#f97316'; // Orange
                    ringColor = 'rgba(249, 115, 22, 0.3)';
                }
                
                // Custom CSS Icon for the "Signal Dot" look with ring
                const iconHtml = `
                    <div style="
                        position: relative;
                        width: 40px;
                        height: 40px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    ">
                        <div style="
                            position: absolute;
                            width: 100%;
                            height: 100%;
                            background-color: ${ringColor};
                            border-radius: 50%;
                            animation: pulse 2s infinite;
                        "></div>
                        <div style="
                            width: 14px;
                            height: 14px;
                            background-color: ${color};
                            border: 2px solid white;
                            border-radius: 50%;
                            z-index: 10;
                        "></div>
                    </div>
                    <style>
                        @keyframes pulse {
                            0% { transform: scale(0.8); opacity: 0.8; }
                            100% { transform: scale(1.5); opacity: 0; }
                        }
                    </style>
                `;

                const icon = L.divIcon({
                    html: iconHtml,
                    className: 'bg-transparent',
                    iconSize: [40, 40],
                    iconAnchor: [20, 20],
                    popupAnchor: [0, -10]
                });

                const threatTitle = threatLevel === 'high' ? "YUQORI XAVF" : threatLevel === 'medium' ? "O'RTA XAVF" : "PAST XAVF";
                const threatClass = threatLevel === 'high' ? "text-red-600 bg-red-50" : threatLevel === 'medium' ? "text-orange-600 bg-orange-50" : "text-green-600 bg-green-50";

                L.marker([item.location.latitude, item.location.longitude], { icon })
                 .addTo(mapRef.current!)
                 .bindPopup(`
                    <div class="min-w-[220px] font-sans">
                        <div class="flex justify-between items-center border-b pb-2 mb-2">
                             <span class="text-[10px] font-bold px-2 py-0.5 rounded ${threatClass}">${threatTitle}</span>
                             <span class="text-[10px] text-gray-400">${new Date(item.timestamp).toLocaleDateString()}</span>
                        </div>
                        <h3 class="font-bold text-base text-gray-900 leading-tight mb-0.5">${item.diagnosis.cropType}</h3>
                        <p class="text-xs text-gray-500 mb-2 italic">Tashxis: ${item.diagnosis.name}</p>
                        
                        <div class="bg-gray-50 p-2 rounded border border-gray-100 mb-2">
                            <span class="text-[9px] font-bold text-gray-400 uppercase block mb-0.5">Xavf Tahlili</span>
                            <p class="text-xs text-gray-700 leading-snug">${item.diagnosis.threatDescription}</p>
                        </div>
                    </div>
                 `);
            }
        });
        
        // If initially "Barcha hududlar", fit bounds after markers added
        if (activeRegion === 'Barcha hududlar' && filteredHistory.length > 0 && filteredHistory[0].location) {
             const bounds = L.latLngBounds(filteredHistory.map(h => [h.location!.latitude, h.location!.longitude]));
             mapRef.current.fitBounds(bounds, { padding: [50, 50] });
        }
    }
  }, [filteredHistory, activeRegion]);

  const regions = ['Barcha hududlar', 'Toshkent', 'Samarqand', 'Farg\'ona', 'Navoiy', 'Qashqadaryo'];

  return (
    <div className="fixed inset-0 bg-gray-900 z-50 flex flex-col">
        {/* Header Overlay */}
        <div className="absolute top-0 left-0 right-0 z-[1000] p-4 pt-6 bg-gradient-to-b from-black/90 via-black/60 to-transparent">
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center text-white gap-3">
                    <button onClick={onBack} className="p-2 bg-white/10 backdrop-blur-md rounded-full hover:bg-white/20 transition-colors border border-white/10">
                         <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
                         </svg>
                    </button>
                    <div>
                        <h1 className="text-xl font-bold leading-none tracking-wide">Mening Dalalarim</h1>
                        <div className="flex items-center gap-1.5 mt-1.5">
                            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]"></span>
                            <span className="text-[10px] font-bold text-green-400 uppercase tracking-widest">REAL VAQT REJIMI</span>
                        </div>
                    </div>
                </div>

                {/* Filter Toggle Button */}
                <button 
                    onClick={() => setShowFilters(!showFilters)}
                    className={`p-2.5 rounded-full backdrop-blur-md border transition-all ${showFilters ? 'bg-green-500 text-white border-green-400' : 'bg-white/10 text-white border-white/10'}`}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                    </svg>
                </button>
            </div>

            {/* Region Filter */}
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide mb-2">
                {regions.map(region => (
                    <button 
                        key={region}
                        onClick={() => handleRegionChange(region)}
                        className={`px-4 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all backdrop-blur-sm
                            ${activeRegion === region 
                                ? 'bg-white/20 text-white border border-white/40 shadow-lg' 
                                : 'bg-black/30 text-gray-400 border border-transparent hover:bg-black/50'}`}
                    >
                        {region}
                    </button>
                ))}
            </div>

            {/* Crop Type Filter (Collapsible) */}
            {showFilters && (
                <div className="animate-in slide-in-from-top-2 fade-in duration-200">
                    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                         <button 
                            onClick={() => setSelectedCrop('all')}
                            className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors border
                                ${selectedCrop === 'all' ? 'bg-green-600 border-green-500 text-white' : 'bg-black/40 border-white/10 text-gray-300'}`}
                        >
                            Barcha Ekinlar
                        </button>
                        {availableCrops.map(crop => (
                            <button 
                                key={crop}
                                onClick={() => setSelectedCrop(crop)}
                                className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors border
                                    ${selectedCrop === crop ? 'bg-green-600 border-green-500 text-white' : 'bg-black/40 border-white/10 text-gray-300'}`}
                            >
                                {crop}
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>

        {/* Map Container */}
        <div className="flex-grow w-full h-full bg-[#111]" ref={mapContainerRef}>
            {filteredHistory.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center z-[500] pointer-events-none">
                    <div className="bg-black/80 backdrop-blur-md text-white p-6 rounded-2xl text-center max-w-xs mx-4 border border-white/10 shadow-2xl">
                        <p className="font-bold text-lg mb-2">Ma'lumot topilmadi</p>
                        <p className="text-sm text-gray-400">Tanlangan filtrlarga mos keladigan ekinlar mavjud emas.</p>
                    </div>
                </div>
            )}
        </div>

        {/* Bottom Stats Panel */}
        <div className="absolute bottom-0 left-0 right-0 z-[1000] bg-[#1a1b1e]/95 backdrop-blur-xl border-t border-white/5 p-6 pb-8 text-white">
            <div className="grid grid-cols-4 gap-0 divide-x divide-white/10 text-center">
                <div className="px-2">
                    <span className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-widest mb-2">JAMI</span>
                    <span className="text-3xl font-bold text-white leading-none">{stats.total}</span>
                </div>
                <div className="px-2">
                    <span className="block text-[10px] font-extrabold text-green-500 uppercase tracking-widest mb-2">PAST XAVF</span>
                    <span className="text-3xl font-bold text-green-500 leading-none">{stats.low}</span>
                </div>
                <div className="px-2">
                    <span className="block text-[10px] font-extrabold text-orange-500 uppercase tracking-widest mb-2">O'RTA</span>
                    <span className="text-3xl font-bold text-orange-500 leading-none">{stats.medium}</span>
                </div>
                <div className="px-2">
                    <span className="block text-[10px] font-extrabold text-red-500 uppercase tracking-widest mb-2">YUQORI</span>
                    <span className="text-3xl font-bold text-red-500 leading-none">{stats.high}</span>
                </div>
            </div>
        </div>
    </div>
  );
};
