
import React, { useState } from 'react';
import type { UserProfile } from '../hooks/useProfile';
import { UserIcon } from '../components/icons/HomeIcons';

interface ProfilePageProps {
    profile: UserProfile;
    onSave: (profile: UserProfile) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ profile, onSave }) => {
    const [name, setName] = useState(profile.name);
    const [location, setLocation] = useState(profile.location);
    const [saved, setSaved] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ name, location });
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4 mb-6">
                <div className="w-20 h-20 bg-brand-light-gray rounded-full flex items-center justify-center text-gray-400 border-2 border-white shadow-md">
                    <UserIcon className="w-10 h-10" />
                </div>
                <div>
                    <h2 className="text-xl font-bold text-brand-dark-gray">{name || "Foydalanuvchi"}</h2>
                    <p className="text-sm text-gray-500">Dehqan.AI a'zosi</p>
                </div>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Ismingiz</label>
                    <input 
                        type="text" 
                        value={name} 
                        onChange={(e) => setName(e.target.value)}
                        className="w-full p-4 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-green focus:border-transparent outline-none transition-all"
                        placeholder="Ismingizni kiriting"
                    />
                </div>
                <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Asosiy Hududingiz</label>
                    <input 
                        type="text" 
                        value={location} 
                        onChange={(e) => setLocation(e.target.value)}
                        className="w-full p-4 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-green focus:border-transparent outline-none transition-all"
                        placeholder="Masalan: Toshkent, Chilonzor"
                    />
                    <p className="text-xs text-gray-400 mt-2">Bu ma'lumot ob-havo prognozlari uchun ishlatiladi.</p>
                </div>

                <button 
                    type="submit" 
                    className="w-full bg-brand-green text-white font-bold py-4 rounded-xl hover:bg-brand-dark-green transition-colors shadow-lg shadow-green-200 mt-4"
                >
                    O'zgarishlarni saqlash
                </button>
            </form>

            {saved && (
                <div className="bg-green-100 border border-green-200 text-green-700 p-4 rounded-xl text-center text-sm font-medium animate-bounce">
                    Profil muvaffaqiyatli yangilandi!
                </div>
            )}
        </div>
    );
};
