
import React, { useEffect, useState } from 'react';
import { getDetailedAlertPlan } from '../services/geminiService';
import { LoadingSpinner } from '../components/LoadingSpinner';

interface AdvicePageProps {
  data: {
    advice: any;
    weather: any;
  } | null;
  onBack: () => void;
}

export const AdvicePage: React.FC<AdvicePageProps> = ({ data, onBack }) => {
  const [detailedPlan, setDetailedPlan] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (data) {
        // If alert is present, fetch detailed plan. Otherwise display daily tip nicely.
        const fetchPlan = async () => {
             const alert = data.advice.alert;
             if (alert.hasAlert) {
                 const plan = await getDetailedAlertPlan(data.weather, alert.title, alert.message);
                 setDetailedPlan(plan);
             }
             setLoading(false);
        };
        fetchPlan();
    }
  }, [data]);

  if (!data) return null;
  
  const { advice, weather } = data;
  const isAlert = advice.alert.hasAlert;
  const themeColor = isAlert ? 'blue' : 'green';
  const bgColor = isAlert ? 'bg-blue-600' : 'bg-green-600';
  const lightBg = isAlert ? 'bg-blue-50' : 'bg-green-50';
  const textColor = isAlert ? 'text-blue-800' : 'text-green-800';

  return (
    <div className="space-y-6">
        {/* Header with Back Button */}
        <div className="flex items-center gap-2 mb-2">
            <button onClick={onBack} className="p-2 bg-gray-100 rounded-full hover:bg-gray-200">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5 text-gray-600">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
                </svg>
            </button>
            <h1 className="text-xl font-bold text-gray-900">Tavsiyalar va Harakatlar</h1>
        </div>

        {/* Hero Card */}
        <div className={`${bgColor} rounded-3xl p-6 text-white shadow-lg`}>
            <div className="mb-4">
                <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
                    {isAlert ? "Ogohlantirish" : "Kun Maslahati"}
                </span>
            </div>
            <h2 className="text-2xl font-bold mb-3 leading-tight">
                {isAlert ? advice.alert.title : advice.dailyTip.title}
            </h2>
            <p className="text-white/90 text-base leading-relaxed">
                {isAlert ? advice.alert.message : advice.dailyTip.message}
            </p>
        </div>

        {/* Detailed Content */}
        {loading ? (
             <LoadingSpinner message="Batafsil reja tuzilmoqda..." />
        ) : (
             <div className="space-y-4 animate-fade-in">
                {isAlert && detailedPlan ? (
                    <>
                        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
                            <h3 className="font-bold text-gray-900 text-lg mb-3 flex items-center gap-2">
                                <span className={`w-1 h-6 ${bgColor} rounded-full`}></span>
                                Sababi
                            </h3>
                            <p className="text-gray-600 leading-relaxed">
                                {detailedPlan.reason}
                            </p>
                        </div>

                        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
                            <h3 className="font-bold text-gray-900 text-lg mb-4 flex items-center gap-2">
                                <span className={`w-1 h-6 ${bgColor} rounded-full`}></span>
                                Harakatlar Rejasi
                            </h3>
                            <ul className="space-y-3">
                                {detailedPlan.actions.map((action: string, idx: number) => (
                                    <li key={idx} className="flex gap-3 items-start">
                                        <div className={`w-6 h-6 rounded-full ${lightBg} ${textColor} flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5`}>
                                            {idx + 1}
                                        </div>
                                        <span className="text-gray-700">{action}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        <div className="bg-gray-100 p-5 rounded-2xl border border-gray-200">
                             <h3 className="font-bold text-gray-500 text-xs uppercase mb-2">Kutilayotgan Davomiylik</h3>
                             <p className="text-gray-900 font-medium">
                                 {detailedPlan.duration}
                             </p>
                        </div>
                    </>
                ) : (
                    // Default view if no alert (Just showing Tip details or Weather summary)
                     <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
                        <h3 className="font-bold text-gray-900 mb-2">Foydali Ma'lumot</h3>
                        <p className="text-gray-600">
                            Bugungi ob-havo sharoiti: <strong>{weather.temp}°C, {weather.description}</strong>. 
                            Dehqonchilik ishlari uchun holat: <strong>{advice.farmingCondition}</strong>.
                        </p>
                     </div>
                )}
             </div>
        )}
    </div>
  );
};
