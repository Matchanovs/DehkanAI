
import React, { useState, useCallback, useEffect } from 'react';
import { ImageUploader } from '../components/ImageUploader';
import { DiagnosisResult } from '../components/DiagnosisResult';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { diagnosePlant } from '../services/geminiService';
import { getCurrentLocation } from '../services/locationService';
import { getWeatherData } from '../services/weatherService';
import type { HistoryItem } from '../types';

interface DiagnosePageProps {
  addHistoryItem: (item: HistoryItem) => void;
  activeItem: HistoryItem | null;
  resetActiveItem: () => void;
  setActiveItem: (item: HistoryItem) => void;
}

export const DiagnosePage: React.FC<DiagnosePageProps> = ({ addHistoryItem, activeItem, resetActiveItem, setActiveItem }) => {
  const [image, setImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // If an active item is passed from the history page, set the image if it exists
    if (activeItem) {
      setImage(activeItem.image);
    }
  }, [activeItem]);

  const handleImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      resetActiveItem(); // Clear any active history item when a new image is uploaded
      setImage(reader.result as string);
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleDiagnose = useCallback(async () => {
    if (!image) return;
    
    setIsLoading(true);
    setError(null);
    resetActiveItem();

    try {
      setLoadingMessage("Joylashuv aniqlanmoqda...");
      // Step 1: Get Location and Weather FIRST to pass to AI
      // This saves a second API call later
      let location = null;
      let weather = null;
      
      try {
          location = await getCurrentLocation();
          setLoadingMessage("Ob-havo ma'lumotlari olinmoqda...");
          weather = await getWeatherData(location);
      } catch (e) {
          console.warn("Location/Weather failed, proceeding without it", e);
          // Fallback to default if location fails, so diagnosis still works
          location = { latitude: 41.3111, longitude: 69.2401 };
          weather = await getWeatherData(location);
      }

      setLoadingMessage("AI tashxis va tavsiyalar tayyorlamoqda...");
      const match = image.match(/^data:(image\/.+);base64,(.+)$/);
      if (!match) throw new Error('Yaroqsiz rasm formati.');
      const [, mimeType, base64Data] = match;
      
      // Step 2: Single AI Call for both Diagnosis and Recommendations
      const diagnosisResult = await diagnosePlant(base64Data, mimeType, weather);
      if (!diagnosisResult) throw new Error("Model javob bermadi.");

      const newHistoryItem: HistoryItem = {
        id: Date.now(),
        timestamp: Date.now(),
        image,
        diagnosis: diagnosisResult,
        location,
        weather,
      };

      addHistoryItem(newHistoryItem);
      setActiveItem(newHistoryItem);

    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : "Noma'lum xatolik yuz berdi.");
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [image, addHistoryItem, setActiveItem, resetActiveItem]);
  
  const handleReset = () => {
    setImage(null);
    resetActiveItem();
    setError(null);
    setIsLoading(false);
  };

  if (isLoading) return <LoadingSpinner message={loadingMessage} />;
  
  if (error) return (
      <div className="text-center text-red-600 bg-red-100 p-4 rounded-lg">
          <h3 className="font-bold text-lg mb-2">Xatolik!</h3>
          <p>{error}</p>
          <button onClick={handleDiagnose} className="mt-4 px-4 py-2 bg-brand-green text-white rounded-lg">Qayta urinish</button>
          <div className="mt-2">
            <button onClick={handleReset} className="text-sm text-gray-500 underline">Boshqa rasm yuklash</button>
          </div>
      </div>
  );

  if (activeItem) return (
      <>
          <DiagnosisResult result={activeItem} />
          <div className="text-center pt-4">
              <button onClick={handleReset} className="w-full sm:w-auto px-6 py-3 bg-brand-green text-white font-bold rounded-xl">Yangi Tashxis</button>
          </div>
      </>
  );

  return (
    <>
      <ImageUploader onImageUpload={handleImageUpload} onDiagnose={handleDiagnose} imagePreview={image} />
      <div className="w-full max-w-2xl text-center mt-6 text-brand-gray text-sm">
        <p><strong>Izoh:</strong> Ushbu tashxis sun'iy intellekt tomonidan taqdim etilgan va faqat tavsiya xususiyatiga ega. Har doim professional agronom bilan maslahatlashing.</p>
      </div>
    </>
  );
};
